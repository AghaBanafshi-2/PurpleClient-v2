# PURPLE CLIENT — Ultimate Minecraft 1.8.9 Forge Client

Developed by: **Agha Banafshi**  
Client Version: **v2.4.0-RELEASE**  
Minecraft Version: **1.8.9** (Forge `11.15.1.2318`)  
Target Language: **Java 8**

---

## Technical Architecture & Features
- **Extensible Module System**: Event-driven modules with robust lifecycle checks and settings hierarchy.
- **Click GUI**: Dark purple Lunar/Badlion inspired layout with smooth category filtering and module cards.
- **HUD Editor**: Drag-and-drop HUD manager with 8px grid snapping, center guidelines, and persistent JSON layout.
- **Persian & English Localization**: Real character shaping for Arabic/Persian letters and RTL support in FontRenderer.
- **Offline Account Manager**: Seamless name switching using reflection on `Minecraft.session`.

---

## How to Build the Mod JAR with Gradle

### Prerequisites
1. **Java Development Kit (JDK) 8** installed (Adoptium Temurin 8 or Oracle JDK 8).
2. `JAVA_HOME` environment variable pointing to your JDK 8 installation directory.

### Build Commands:
#### Windows (CMD / PowerShell):
```cmd
gradlew.bat setupDecompWorkspace
gradlew.bat build
```

#### macOS / Linux (Terminal):
```bash
chmod +x gradlew
./gradlew setupDecompWorkspace
./gradlew build
```

### Output File
Your compiled Forge 1.8.9 mod JAR will be output to:
```
build/libs/PurpleClient-1.8.9-2.4.0.jar
```
Drop this JAR into `.minecraft/mods` and launch Minecraft with Forge 1.8.9!
