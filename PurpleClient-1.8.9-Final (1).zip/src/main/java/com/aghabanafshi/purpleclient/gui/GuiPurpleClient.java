package com.aghabanafshi.purpleclient.gui;

import com.aghabanafshi.purpleclient.PurpleClient;
import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import com.aghabanafshi.purpleclient.settings.BooleanSetting;
import com.aghabanafshi.purpleclient.settings.NumberSetting;
import com.aghabanafshi.purpleclient.settings.Setting;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.List;

/**
 * Modern Dark Purple Lunar/Badlion Click GUI.
 */
public class GuiPurpleClient extends GuiScreen {
    private Category currentCategory = Category.COMBAT;
    private int scrollOffset = 0;
    private Module selectedModuleForSetting = null;

    @Override
    public void initGui() {
        this.buttonList.clear();
        int catY = 45;
        int id = 0;
        for (Category cat : Category.values()) {
            this.buttonList.add(new GuiButton(id++, 15, catY, 85, 20, cat.getEnglishName()));
            catY += 24;
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id < Category.values().length) {
            this.currentCategory = Category.values()[button.id];
            this.selectedModuleForSetting = null;
            this.scrollOffset = 0;
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int dWheel = Mouse.getEventDWheel();
        if (dWheel != 0) {
            scrollOffset += (dWheel > 0 ? -18 : 18);
            if (scrollOffset < 0) scrollOffset = 0;
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        // Main window backdrop
        Gui.drawRect(10, 10, width - 10, height - 10, 0xEE0D071A);
        // Header
        Gui.drawRect(10, 10, width - 10, 36, 0xFF4A0E4E);
        drawCenteredString(fontRendererObj, "§d§lPURPLE CLIENT §7| §f" + currentCategory.getEnglishName(), width / 2, 18, 0xFFFFFFFF);

        // Sidebar backdrop
        Gui.drawRect(10, 36, 105, height - 10, 0xDD140B28);

        // Module cards
        int startX = 115;
        int cardY = 45 - scrollOffset;
        List<Module> mods = PurpleClient.getInstance().getModuleManager().getModulesByCategory(currentCategory);

        for (Module m : mods) {
            if (cardY + 30 > 36 && cardY < height - 15) {
                boolean hovered = mouseX >= startX && mouseX <= startX + 220 && mouseY >= cardY && mouseY <= cardY + 28;
                int cardBg = m.isEnabled() ? (hovered ? 0xFF3B1259 : 0xFF2B0A42) : (hovered ? 0xFF1D0E36 : 0xFF160A2A);
                Gui.drawRect(startX, cardY, startX + 220, cardY + 28, cardBg);

                fontRendererObj.drawStringWithShadow(m.getName(), startX + 8, cardY + 6, 0xFFFFFFFF);
                String state = m.isEnabled() ? "§aON" : "§cOFF";
                fontRendererObj.drawStringWithShadow(state, startX + 195, cardY + 6, 0xFFFFFFFF);
                fontRendererObj.drawStringWithShadow("§7" + m.getDescription(), startX + 8, cardY + 16, 0xFFA855F7);
            }
            cardY += 32;
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        int startX = 115;
        int cardY = 45 - scrollOffset;
        List<Module> mods = PurpleClient.getInstance().getModuleManager().getModulesByCategory(currentCategory);

        for (Module m : mods) {
            if (mouseX >= startX && mouseX <= startX + 220 && mouseY >= cardY && mouseY <= cardY + 28) {
                if (mouseButton == 0) {
                    m.toggle();
                    PurpleClient.getInstance().getConfigManager().saveConfig();
                }
                return;
            }
            cardY += 32;
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
