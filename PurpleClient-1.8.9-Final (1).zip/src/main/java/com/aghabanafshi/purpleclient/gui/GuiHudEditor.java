package com.aghabanafshi.purpleclient.gui;

import com.aghabanafshi.purpleclient.PurpleClient;
import com.aghabanafshi.purpleclient.module.Module;
import com.aghabanafshi.purpleclient.module.impl.hud.HudModule;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

public class GuiHudEditor extends GuiScreen {
    private HudModule draggingModule = null;
    private int dragOffsetX = 0;
    private int dragOffsetY = 0;

    @Override
    public void initGui() {
        this.buttonList.add(new GuiButton(1, width / 2 - 70, height - 30, 140, 20, "Save & Exit"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            PurpleClient.getInstance().getConfigManager().saveConfig();
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // Subtle dark purple translucent overlay
        drawRect(0, 0, width, height, 0x660B0418);

        // Center alignment guide lines
        drawRect(width / 2, 0, width / 2 + 1, height, 0x33A855F7);
        drawRect(0, height / 2, width, height / 2 + 1, 0x33A855F7);

        drawCenteredString(fontRendererObj, "§d§lHUD EDITOR §7(Drag widgets with mouse)", width / 2, 10, 0xFFFFFFFF);

        // Render borders around each HUD element
        for (Module m : PurpleClient.getInstance().getModuleManager().getModules()) {
            if (m instanceof HudModule && m.isEnabled()) {
                HudModule hud = (HudModule) m;
                hud.render();
                // Outline border
                Gui.drawRect(hud.getX() - 1, hud.getY() - 1, hud.getX() + hud.getWidth() + 1, hud.getY(), 0xFFA855F7);
                Gui.drawRect(hud.getX() - 1, hud.getY() + hud.getHeight(), hud.getX() + hud.getWidth() + 1, hud.getY() + hud.getHeight() + 1, 0xFFA855F7);
                Gui.drawRect(hud.getX() - 1, hud.getY(), hud.getX(), hud.getY() + hud.getHeight(), 0xFFA855F7);
                Gui.drawRect(hud.getX() + hud.getWidth(), hud.getY(), hud.getX() + hud.getWidth() + 1, hud.getY() + hud.getHeight(), 0xFFA855F7);
            }
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton == 0) {
            for (Module m : PurpleClient.getInstance().getModuleManager().getModules()) {
                if (m instanceof HudModule && m.isEnabled()) {
                    HudModule hud = (HudModule) m;
                    if (mouseX >= hud.getX() && mouseX <= hud.getX() + hud.getWidth() &&
                        mouseY >= hud.getY() && mouseY <= hud.getY() + hud.getHeight()) {
                        draggingModule = hud;
                        dragOffsetX = mouseX - hud.getX();
                        dragOffsetY = mouseY - hud.getY();
                        return;
                    }
                }
            }
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        if (state == 0) {
            draggingModule = null;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingModule != null && clickedMouseButton == 0) {
            int newX = mouseX - dragOffsetX;
            int newY = mouseY - dragOffsetY;
            // Grid snapping (8px)
            newX = Math.round((float)newX / 8) * 8;
            newY = Math.round((float)newY / 8) * 8;
            draggingModule.setX(newX);
            draggingModule.setY(newY);
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
