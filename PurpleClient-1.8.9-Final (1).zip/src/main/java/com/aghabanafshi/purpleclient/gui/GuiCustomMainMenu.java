package com.aghabanafshi.purpleclient.gui;

import com.aghabanafshi.purpleclient.PurpleClient;
import net.minecraft.client.gui.*;

import java.io.IOException;

public class GuiCustomMainMenu extends GuiScreen {
    @Override
    public void initGui() {
        int btnW = 160;
        int btnH = 20;
        int startX = width / 2 - btnW / 2;
        int startY = height / 4 + 48;

        this.buttonList.add(new GuiButton(1, startX, startY, btnW, btnH, "Singleplayer"));
        this.buttonList.add(new GuiButton(2, startX, startY + 24, btnW, btnH, "Multiplayer"));
        this.buttonList.add(new GuiButton(3, startX, startY + 48, btnW, btnH, "Purple Mods (R-Shift)"));
        this.buttonList.add(new GuiButton(4, startX, startY + 72, btnW, btnH, "HUD Editor (H)"));
        this.buttonList.add(new GuiButton(0, startX, startY + 96, btnW, btnH, "Minecraft Options..."));
        this.buttonList.add(new GuiButton(5, startX, startY + 120, btnW, btnH, "Quit Game"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 1: mc.displayGuiScreen(new GuiSelectWorld(this)); break;
            case 2: mc.displayGuiScreen(new GuiMultiplayer(this)); break;
            case 3: mc.displayGuiScreen(new GuiPurpleClient()); break;
            case 4: mc.displayGuiScreen(new GuiHudEditor()); break;
            case 0: mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings)); break;
            case 5: mc.shutdown(); break;
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        Gui.drawRect(0, 0, width, height, 0xDD0D061C);

        drawCenteredString(fontRendererObj, "§d§lPURPLE CLIENT", width / 2, height / 4, 0xFFFFFFFF);
        drawCenteredString(fontRendererObj, "§7Competitive Minecraft 1.8.9 Forge Client §f- §ev" + PurpleClient.VERSION, width / 2, height / 4 + 14, 0xFFA855F7);
        drawCenteredString(fontRendererObj, "§8Developed by " + PurpleClient.AUTHOR, width / 2, height / 4 + 26, 0xFF888888);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}
