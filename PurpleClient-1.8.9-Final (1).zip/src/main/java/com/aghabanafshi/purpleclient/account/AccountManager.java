package com.aghabanafshi.purpleclient.account;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class AccountManager {
    private final List<Account> accounts = new ArrayList<Account>();
    private Account activeAccount;

    public AccountManager() {
        Account defaultAcc = new Account("AghaBanafshi", "purple_warrior");
        accounts.add(defaultAcc);
        this.activeAccount = defaultAcc;
    }

    public void switchAccount(Account account) {
        if (account == null) return;
        this.activeAccount = account;
        try {
            Session newSession = new Session(account.getUsername(), account.getUuid(), "-", "legacy");
            Field sessionField = null;
            for (Field f : Minecraft.class.getDeclaredFields()) {
                if (f.getType().equals(Session.class)) {
                    sessionField = f;
                    break;
                }
            }
            if (sessionField != null) {
                sessionField.setAccessible(true);
                sessionField.set(Minecraft.getMinecraft(), newSession);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean validateUsername(String username) {
        return username != null && username.matches("^[a-zA-Z0-9_]{3,16}$");
    }

    public List<Account> getAccounts() { return accounts; }
    public Account getActiveAccount() { return activeAccount; }
}
