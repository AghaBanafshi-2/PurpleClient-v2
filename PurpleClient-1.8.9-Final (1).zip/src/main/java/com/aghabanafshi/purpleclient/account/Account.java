package com.aghabanafshi.purpleclient.account;

import java.util.UUID;

public class Account {
    private final String username;
    private final String uuid;
    private final String skinType;

    public Account(String username, String skinType) {
        this.username = username;
        this.uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes()).toString();
        this.skinType = skinType != null ? skinType : "purple_warrior";
    }

    public String getUsername() { return username; }
    public String getUuid() { return uuid; }
    public String getSkinType() { return skinType; }
}
