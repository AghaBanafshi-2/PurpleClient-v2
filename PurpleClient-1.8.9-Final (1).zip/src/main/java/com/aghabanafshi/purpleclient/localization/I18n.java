package com.aghabanafshi.purpleclient.localization;

import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class I18n {
    private String currentLang = "en_us";
    private final Map<String, String> translations = new HashMap<String, String>();

    public I18n() {
        loadLanguage("en_us");
    }

    public void setLanguage(String lang) {
        this.currentLang = lang;
        loadLanguage(lang);
    }

    public String getCurrentLanguage() {
        return currentLang;
    }

    public boolean isRTL() {
        return "fa_ir".equalsIgnoreCase(currentLang);
    }

    public String format(String key, Object... args) {
        String val = translations.get(key);
        if (val == null) val = key;
        if (args.length > 0) {
            val = String.format(val, args);
        }
        if (isRTL()) {
            return PersianShaper.shape(val);
        }
        return val;
    }

    private void loadLanguage(String lang) {
        translations.clear();
        try {
            String path = "/assets/purpleclient/lang/" + lang + ".lang";
            InputStream is = getClass().getResourceAsStream(path);
            if (is != null) {
                for (String line : IOUtils.readLines(is, StandardCharsets.UTF_8)) {
                    if (line.startsWith("#") || !line.contains("=")) continue;
                    int eq = line.indexOf('=');
                    translations.put(line.substring(0, eq).trim(), line.substring(eq + 1).trim());
                }
                is.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
