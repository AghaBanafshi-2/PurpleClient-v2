package com.aghabanafshi.purpleclient.localization;

/**
 * Persian Character Shaper and Bidi Processor for Minecraft 1.8.9.
 * Shapes Arabic/Persian letters into their contextual Unicode glyphs (Isolated, Initial, Medial, Final).
 */
public class PersianShaper {

    public static String shape(String input) {
        if (input == null || input.isEmpty()) return "";
        if (!containsPersian(input)) return input;

        // Shape letters
        StringBuilder sb = new StringBuilder();
        char[] chars = input.toCharArray();
        int len = chars.length;

        for (int i = 0; i < len; i++) {
            char current = chars[i];
            boolean prevConnects = (i > 0) && connectsAfter(chars[i - 1]);
            boolean nextConnects = (i < len - 1) && connectsBefore(chars[i + 1]);

            sb.append(getGlyph(current, prevConnects, nextConnects));
        }

        // Reorder RTL words for Minecraft 1.8.9 FontRenderer
        return reorderBidi(sb.toString());
    }

    private static boolean containsPersian(String text) {
        for (char c : text.toCharArray()) {
            if ((c >= 0x0600 && c <= 0x06FF) || (c >= 0xFB50 && c <= 0xFDFF)) return true;
        }
        return false;
    }

    private static boolean connectsBefore(char c) {
        return (c >= 0x0621 && c <= 0x064A) || (c >= 0x067E && c <= 0x06CC);
    }

    private static boolean connectsAfter(char c) {
        // Letters that don't connect to subsequent characters: Alef, Dal, Zal, Re, Ze, Zhe, Vav
        if (c == 0x0627 || c == 0x062F || c == 0x0630 || c == 0x0631 || c == 0x0632 || c == 0x0698 || c == 0x0648) {
            return false;
        }
        return connectsBefore(c);
    }

    private static char getGlyph(char c, boolean prevConnects, boolean nextConnects) {
        switch (c) {
            case 'ب': return prevConnects ? (nextConnects ? '\uFE92' : '\uFE90') : (nextConnects ? '\uFE91' : '\uFE8F');
            case 'پ': return prevConnects ? (nextConnects ? '\uFB59' : '\uFB58') : (nextConnects ? '\uFB57' : '\uFB56');
            case 'ت': return prevConnects ? (nextConnects ? '\uFE98' : '\uFE96') : (nextConnects ? '\uFE97' : '\uFE95');
            case 'م': return prevConnects ? (nextConnects ? '\uFEE4' : '\uFEE2') : (nextConnects ? '\uFEE3' : '\uFEE1');
            case 'ن': return prevConnects ? (nextConnects ? '\uFEE8' : '\uFEE6') : (nextConnects ? '\uFEE7' : '\uFEE5');
            case 'ی': return prevConnects ? (nextConnects ? '\uFEF4' : '\uFEF2') : (nextConnects ? '\uFEF3' : '\uFEF1');
            case 'ک': return prevConnects ? (nextConnects ? '\uFEDB' : '\uFEDA') : (nextConnects ? '\uFED9' : '\uFED8');
            case 'گ': return prevConnects ? (nextConnects ? '\uFB95' : '\uFB94') : (nextConnects ? '\uFB93' : '\uFB92');
            case 'ل': return prevConnects ? (nextConnects ? '\uFEDE' : '\uFEDD') : (nextConnects ? '\uFEDC' : '\uFEDB');
            case 'س': return prevConnects ? (nextConnects ? '\uFEB4' : '\uFEB2') : (nextConnects ? '\uFEB3' : '\uFEB1');
            case 'ش': return prevConnects ? (nextConnects ? '\uFEB8' : '\uFEB6') : (nextConnects ? '\uFEB7' : '\uFEB5');
            default: return c;
        }
    }

    private static String reorderBidi(String text) {
        String[] words = text.split(" ");
        StringBuilder out = new StringBuilder();
        for (int i = words.length - 1; i >= 0; i--) {
            out.append(words[i]);
            if (i > 0) out.append(" ");
        }
        return out.toString();
    }
}
