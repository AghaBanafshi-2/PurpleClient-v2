package com.aghabanafshi.purpleclient.settings;

public class NumberSetting extends Setting<Double> {
    private final double min;
    private final double max;
    private final double step;

    public NumberSetting(String name, String id, double defaultValue, double min, double max, double step) {
        super(name, id, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }

    @Override
    public void setValue(Double value) {
        if (value < min) value = min;
        if (value > max) value = max;
        double rounded = Math.round(value / step) * step;
        super.setValue(rounded);
    }
}
