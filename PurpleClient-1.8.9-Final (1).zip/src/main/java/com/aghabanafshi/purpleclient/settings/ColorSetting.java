package com.aghabanafshi.purpleclient.settings;

public class ColorSetting extends Setting<Integer> {
    private boolean chroma = false;

    public ColorSetting(String name, String id, int defaultHex) {
        super(name, id, defaultHex);
    }

    public boolean isChroma() { return chroma; }
    public void setChroma(boolean chroma) { this.chroma = chroma; }

    public int getRed() { return (getValue() >> 16) & 0xFF; }
    public int getGreen() { return (getValue() >> 8) & 0xFF; }
    public int getBlue() { return getValue() & 0xFF; }
    public int getAlpha() { return (getValue() >> 24) & 0xFF; }
}
