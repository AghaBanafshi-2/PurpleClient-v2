package com.aghabanafshi.purpleclient.settings;

public class ModeSetting extends Setting<String> {
    private final String[] modes;
    private int index;

    public ModeSetting(String name, String id, String defaultMode, String[] modes) {
        super(name, id, defaultMode);
        this.modes = modes;
        this.index = 0;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(defaultMode)) {
                this.index = i;
                break;
            }
        }
    }

    public String[] getModes() { return modes; }
    public int getIndex() { return index; }

    public void cycle() {
        if (modes.length == 0) return;
        index = (index + 1) % modes.length;
        setValue(modes[index]);
    }

    public void setIndex(int idx) {
        if (idx >= 0 && idx < modes.length) {
            this.index = idx;
            setValue(modes[idx]);
        }
    }
}
