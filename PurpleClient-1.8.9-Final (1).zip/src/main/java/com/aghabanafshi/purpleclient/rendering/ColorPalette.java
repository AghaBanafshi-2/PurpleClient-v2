package com.aghabanafshi.purpleclient.rendering;

public class ColorPalette {
    public int primaryColor = 0xFF7B1FA2;
    public int accentColor = 0xFFA855F7;
    public int backgroundColor = 0xEE110726;
    public int surfaceColor = 0xFF190C36;
    public int textColor = 0xFFFFFFFF;
    public int borderColor = 0xFF9333EA;

    public void setTheme(int primary, int accent, int bg, int surface) {
        this.primaryColor = primary;
        this.accentColor = accent;
        this.backgroundColor = bg;
        this.surfaceColor = surface;
    }
}
