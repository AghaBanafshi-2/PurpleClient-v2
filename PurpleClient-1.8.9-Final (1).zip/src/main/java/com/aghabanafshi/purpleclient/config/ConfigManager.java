package com.aghabanafshi.purpleclient.config;

import com.aghabanafshi.purpleclient.PurpleClient;
import com.aghabanafshi.purpleclient.module.Module;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class ConfigManager {
    private final File dir;
    private final File configFile;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ConfigManager() {
        this.dir = new File(Minecraft.getMinecraft().mcDataDir, "purpleclient");
        if (!dir.exists()) dir.mkdirs();
        this.configFile = new File(dir, "config.json");
    }

    public void saveConfig() {
        try {
            JsonObject root = new JsonObject();
            root.addProperty("version", PurpleClient.VERSION);
            root.addProperty("language", PurpleClient.getInstance().getI18n().getCurrentLanguage());

            JsonObject mods = new JsonObject();
            for (Module m : PurpleClient.getInstance().getModuleManager().getModules()) {
                JsonObject modJson = new JsonObject();
                modJson.addProperty("enabled", m.isEnabled());
                modJson.addProperty("keybind", m.getKeyCode());
                mods.add(m.getName(), modJson);
            }
            root.add("modules", mods);

            FileWriter writer = new FileWriter(configFile);
            gson.toJson(root, writer);
            writer.close();
        } catch (Exception e) {
            PurpleClient.LOGGER.error("Failed to save Purple Client configuration", e);
        }
    }

    public void loadConfig() {
        if (!configFile.exists()) {
            saveConfig();
            return;
        }
        try {
            FileReader reader = new FileReader(configFile);
            JsonObject root = new JsonParser().parse(reader).getAsJsonObject();
            reader.close();

            if (root.has("modules")) {
                JsonObject mods = root.getAsJsonObject("modules");
                for (Module m : PurpleClient.getInstance().getModuleManager().getModules()) {
                    if (mods.has(m.getName())) {
                        JsonObject modJson = mods.getAsJsonObject(m.getName());
                        if (modJson.has("enabled")) {
                            m.setEnabled(modJson.get("enabled").getAsBoolean());
                        }
                        if (modJson.has("keybind")) {
                            m.setKeyCode(modJson.get("keybind").getAsInt());
                        }
                    }
                }
            }
        } catch (Exception e) {
            PurpleClient.LOGGER.error("Failed to load Purple Client configuration", e);
        }
    }
}
