package com.aghabanafshi.purpleclient;

import com.aghabanafshi.purpleclient.account.AccountManager;
import com.aghabanafshi.purpleclient.config.ConfigManager;
import com.aghabanafshi.purpleclient.event.ClientEvents;
import com.aghabanafshi.purpleclient.gui.GuiHudEditor;
import com.aghabanafshi.purpleclient.gui.GuiPurpleClient;
import com.aghabanafshi.purpleclient.localization.I18n;
import com.aghabanafshi.purpleclient.module.ModuleManager;
import com.aghabanafshi.purpleclient.rendering.ColorPalette;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

/**
 * PURPLE CLIENT - Ultimate Minecraft 1.8.9 Forge Client
 * Engineered by Agha Banafshi for competitive PvP, high FPS, and precision customization.
 */
@Mod(modid = PurpleClient.MODID, name = PurpleClient.NAME, version = PurpleClient.VERSION, clientSideOnly = true)
public class PurpleClient {
    public static final String MODID = "purpleclient";
    public static final String NAME = "Purple Client";
    public static final String VERSION = "2.4.0";
    public static final String AUTHOR = "Agha Banafshi";

    public static final Logger LOGGER = LogManager.getLogger("PurpleClient");

    @Mod.Instance(MODID)
    public static PurpleClient instance;

    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private AccountManager accountManager;
    private ColorPalette colorPalette;
    private I18n i18n;

    public KeyBinding keyBindGui;
    public KeyBinding keyBindHud;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER.info("[PurpleClient] Pre-initializing Purple Client v{} by {}...", VERSION, AUTHOR);
        this.i18n = new I18n();
        this.colorPalette = new ColorPalette();
        this.accountManager = new AccountManager();
        this.configManager = new ConfigManager();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        LOGGER.info("[PurpleClient] Initializing module subsystem, keybindings and event bus...");
        this.moduleManager = new ModuleManager();
        this.moduleManager.registerModules();

        // Register default keybindings
        this.keyBindGui = new KeyBinding("key.purpleclient.gui", Keyboard.KEY_RSHIFT, "Purple Client");
        this.keyBindHud = new KeyBinding("key.purpleclient.hud", Keyboard.KEY_H, "Purple Client");

        ClientRegistry.registerKeyBinding(this.keyBindGui);
        ClientRegistry.registerKeyBinding(this.keyBindHud);

        // Register event listener
        MinecraftForge.EVENT_BUS.register(new ClientEvents(this));
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        // Load configuration safely after all items and blocks are registered
        this.configManager.loadConfig();
        LOGGER.info("[PurpleClient] Initialization complete. Ready for PvP.");
    }

    public static PurpleClient getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public AccountManager getAccountManager() {
        return accountManager;
    }

    public ColorPalette getColorPalette() {
        return colorPalette;
    }

    public I18n getI18n() {
        return i18n;
    }
}
