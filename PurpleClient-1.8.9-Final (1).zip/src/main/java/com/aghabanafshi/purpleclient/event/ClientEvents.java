package com.aghabanafshi.purpleclient.event;

import com.aghabanafshi.purpleclient.PurpleClient;
import com.aghabanafshi.purpleclient.gui.GuiCustomMainMenu;
import com.aghabanafshi.purpleclient.gui.GuiHudEditor;
import com.aghabanafshi.purpleclient.gui.GuiPurpleClient;
import com.aghabanafshi.purpleclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class ClientEvents {
    private final PurpleClient client;
    private final Minecraft mc = Minecraft.getMinecraft();

    public ClientEvents(PurpleClient client) {
        this.client = client;
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (mc.currentScreen != null) return;

        if (client.keyBindGui.isPressed()) {
            mc.displayGuiScreen(new GuiPurpleClient());
            return;
        }

        if (client.keyBindHud.isPressed()) {
            mc.displayGuiScreen(new GuiHudEditor());
            return;
        }

        // Check module custom keybinds
        if (Keyboard.getEventKeyState()) {
            int key = Keyboard.getEventKey();
            if (key != 0) {
                for (Module m : client.getModuleManager().getModules()) {
                    if (m.getKeyCode() == key) {
                        m.toggle();
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent event) {
        // Intercept standard GuiMainMenu to display Purple Client main menu
        if (event.gui instanceof GuiMainMenu && !(event.gui instanceof GuiCustomMainMenu)) {
            event.gui = new GuiCustomMainMenu();
        }
    }
}
