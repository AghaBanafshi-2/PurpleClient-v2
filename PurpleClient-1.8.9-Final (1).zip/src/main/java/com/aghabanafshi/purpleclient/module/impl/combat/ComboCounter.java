package com.aghabanafshi.purpleclient.module.impl.combat;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ComboCounter extends Module {
    private int combo = 0;
    private long lastHitTime = 0;

    public ComboCounter() {
        super("Combo Counter", "Tracks consecutive PvP hit streaks", Category.COMBAT, 0);
        setEnabled(true);
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        combo++;
        lastHitTime = System.currentTimeMillis();
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        if (!isEnabled()) return;
        if (System.currentTimeMillis() - lastHitTime > 2000) {
            combo = 0;
        }
        if (combo > 0) {
            String text = "Combo: §d" + combo;
            mc.fontRendererObj.drawStringWithShadow(text, 10, 275, 0xFFFFFFFF);
        }
    }
}
