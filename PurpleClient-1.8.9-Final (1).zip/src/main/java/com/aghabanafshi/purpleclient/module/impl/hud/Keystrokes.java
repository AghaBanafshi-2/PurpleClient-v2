package com.aghabanafshi.purpleclient.module.impl.hud;

import com.aghabanafshi.purpleclient.settings.BooleanSetting;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

public class Keystrokes extends HudModule {
    public BooleanSetting showMouse = new BooleanSetting("Show Mouse Buttons", "mouse", true);
    public BooleanSetting showSpace = new BooleanSetting("Show Spacebar", "space", true);

    public Keystrokes() {
        super("Keystrokes", "Displays WASD and mouse buttons on screen", 10, 48);
        this.width = 68;
        this.height = showSpace.isEnabled() ? 80 : 66;
        addSetting(showMouse);
        addSetting(showSpace);
        setEnabled(true);
    }

    @Override
    public void render() {
        if (!isEnabled()) return;
        boolean w = mc.gameSettings.keyBindForward.isKeyDown();
        boolean a = mc.gameSettings.keyBindLeft.isKeyDown();
        boolean s = mc.gameSettings.keyBindBack.isKeyDown();
        boolean d = mc.gameSettings.keyBindRight.isKeyDown();

        drawKey("W", x + 23, y, 22, 20, w);
        drawKey("A", x, y + 22, 22, 20, a);
        drawKey("S", x + 23, y + 22, 22, 20, s);
        drawKey("D", x + 46, y + 22, 22, 20, d);

        int currentY = y + 44;
        if (showMouse.isEnabled()) {
            boolean lmb = Mouse.isButtonDown(0);
            boolean rmb = Mouse.isButtonDown(1);
            drawKey("LMB", x, currentY, 33, 18, lmb);
            drawKey("RMB", x + 35, currentY, 33, 18, rmb);
            currentY += 20;
        }

        if (showSpace.isEnabled()) {
            boolean space = mc.gameSettings.keyBindJump.isKeyDown();
            drawKey("-----", x, currentY, 68, 12, space);
            currentY += 14;
        }

        this.height = currentY - y;
    }

    private void drawKey(String key, int kx, int ky, int kw, int kh, boolean pressed) {
        int bgColor = pressed ? 0xAA9333EA : 0x88120726;
        Gui.drawRect(kx, ky, kx + kw, ky + kh, bgColor);
        int textColor = pressed ? 0xFFFFFFFF : 0xFFD8B4FE;
        int textW = mc.fontRendererObj.getStringWidth(key);
        mc.fontRendererObj.drawStringWithShadow(key, kx + (kw - textW) / 2, ky + (kh - 8) / 2, textColor);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        render();
    }
}
