package com.aghabanafshi.purpleclient.module.impl.movement;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ToggleSprint extends Module {
    public ToggleSprint() {
        super("Toggle Sprint", "Keeps player sprinting automatically without holding key", Category.MOVEMENT, 0);
        setEnabled(true);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (!isEnabled() || mc.thePlayer == null) return;
        // Check player movement input: only sprint forward if hunger > 6 and not colliding or sneaked
        if (mc.thePlayer.movementInput.moveForward > 0 && !mc.thePlayer.isSneaking() && !mc.thePlayer.isCollidedHorizontally && mc.thePlayer.getFoodStats().getFoodLevel() > 6) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        }
    }

    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        }
    }
}
