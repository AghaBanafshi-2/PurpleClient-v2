package com.aghabanafshi.purpleclient.module;

import com.aghabanafshi.purpleclient.PurpleClient;
import com.aghabanafshi.purpleclient.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();
    private final String name;
    private final String description;
    private final Category category;
    private int keyCode;
    private boolean enabled;
    private final List<Setting<?>> settings = new ArrayList<Setting<?>>();

    public Module(String name, String description, Category category, int keyCode) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.keyCode = keyCode;
        this.enabled = false;
    }

    public void addSetting(Setting<?> setting) {
        this.settings.add(setting);
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public Setting<?> getSettingById(String id) {
        for (Setting<?> s : settings) {
            if (s.getId().equalsIgnoreCase(id)) return s;
        }
        return null;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        try {
            if (enabled) {
                MinecraftForge.EVENT_BUS.register(this);
                onEnable();
            } else {
                MinecraftForge.EVENT_BUS.unregister(this);
                onDisable();
            }
        } catch (Exception e) {
            PurpleClient.LOGGER.error("Failed to toggle module: " + name, e);
        }
    }

    public void onEnable() {}
    public void onDisable() {}

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public int getKeyCode() { return keyCode; }
    public void setKeyCode(int keyCode) { this.keyCode = keyCode; }
    public boolean isEnabled() { return enabled; }
}
