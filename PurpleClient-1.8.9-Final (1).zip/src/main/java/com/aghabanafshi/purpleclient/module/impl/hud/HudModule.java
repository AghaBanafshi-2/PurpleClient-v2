package com.aghabanafshi.purpleclient.module.impl.hud;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import com.aghabanafshi.purpleclient.settings.BooleanSetting;
import com.aghabanafshi.purpleclient.settings.NumberSetting;
import net.minecraft.client.gui.ScaledResolution;

public abstract class HudModule extends Module {
    public int x = 10;
    public int y = 10;
    public int width = 60;
    public int height = 15;

    public BooleanSetting background = new BooleanSetting("Background Box", "bg", true);
    public NumberSetting scale = new NumberSetting("Scale", "scale", 1.0, 0.5, 2.0, 0.1);
    public NumberSetting opacity = new NumberSetting("Opacity", "opacity", 1.0, 0.2, 1.0, 0.05);

    public HudModule(String name, String description, int defaultX, int defaultY) {
        super(name, description, Category.HUD, 0);
        this.x = defaultX;
        this.y = defaultY;
        addSetting(background);
        addSetting(scale);
        addSetting(opacity);
    }

    public abstract void render();

    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
