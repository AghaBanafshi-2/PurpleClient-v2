package com.aghabanafshi.purpleclient.module.impl.hud;

import com.aghabanafshi.purpleclient.settings.BooleanSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ArmorStatus extends HudModule {
    public BooleanSetting showDamage = new BooleanSetting("Show Durability", "durability", true);

    public ArmorStatus() {
        super("Armor Status", "Displays currently equipped armor durability and items", 10, 130);
        addSetting(showDamage);
        this.width = 60;
        this.height = 72;
        setEnabled(true);
    }

    @Override
    public void render() {
        if (!isEnabled() || mc.thePlayer == null) return;
        int currentY = y;
        for (int i = 3; i >= 0; i--) {
            ItemStack is = mc.thePlayer.inventory.armorInventory[i];
            if (is != null) {
                mc.getRenderItem().renderItemAndEffectIntoGUI(is, x, currentY);
                if (showDamage.isEnabled()) {
                    int remaining = is.getMaxDamage() - is.getItemDamage();
                    mc.fontRendererObj.drawStringWithShadow(String.valueOf(remaining), x + 20, currentY + 4, 0xFFE9D5FF);
                }
                currentY += 18;
            }
        }
        this.height = Math.max(18, currentY - y);
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        render();
    }
}
