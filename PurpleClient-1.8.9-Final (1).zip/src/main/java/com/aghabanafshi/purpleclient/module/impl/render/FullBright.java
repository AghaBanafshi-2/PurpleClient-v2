package com.aghabanafshi.purpleclient.module.impl.render;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;

public class FullBright extends Module {
    private float oldGamma = 1.0F;

    public FullBright() {
        super("FullBright", "Increases brightness so dark areas and caves are fully illuminated", Category.RENDER, 0);
    }

    @Override
    public void onEnable() {
        if (mc.gameSettings != null) {
            oldGamma = mc.gameSettings.gammaSetting;
            mc.gameSettings.gammaSetting = 100.0F;
        }
    }

    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            mc.gameSettings.gammaSetting = oldGamma;
        }
    }
}
