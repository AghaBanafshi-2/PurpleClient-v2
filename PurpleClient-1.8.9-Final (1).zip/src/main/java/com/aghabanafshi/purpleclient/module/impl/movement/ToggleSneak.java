package com.aghabanafshi.purpleclient.module.impl.movement;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ToggleSneak extends Module {
    public ToggleSneak() {
        super("Toggle Sneak", "Toggles sneak mode without getting stuck in chests", Category.MOVEMENT, 0);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (!isEnabled() || mc.thePlayer == null) return;
        if (mc.currentScreen == null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
        }
    }

    @Override
    public void onDisable() {
        if (mc.gameSettings != null) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
        }
    }
}
