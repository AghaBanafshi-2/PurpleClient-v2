package com.aghabanafshi.purpleclient.module;

import com.aghabanafshi.purpleclient.module.impl.combat.ReachDisplay;
import com.aghabanafshi.purpleclient.module.impl.combat.ComboCounter;
import com.aghabanafshi.purpleclient.module.impl.movement.ToggleSprint;
import com.aghabanafshi.purpleclient.module.impl.movement.ToggleSneak;
import com.aghabanafshi.purpleclient.module.impl.render.OldAnimations;
import com.aghabanafshi.purpleclient.module.impl.render.FullBright;
import com.aghabanafshi.purpleclient.module.impl.hud.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<Module>();

    public void registerModules() {
        // Combat
        addModule(new ReachDisplay());
        addModule(new ComboCounter());

        // Movement
        addModule(new ToggleSprint());
        addModule(new ToggleSneak());

        // Render
        addModule(new OldAnimations());
        addModule(new FullBright());

        // HUD
        addModule(new FpsDisplay());
        addModule(new CpsCounter());
        addModule(new Keystrokes());
        addModule(new ArmorStatus());
        addModule(new Coordinates());
    }

    private void addModule(Module module) {
        if (module != null && !modules.contains(module)) {
            modules.add(module);
        }
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> getModulesByCategory(Category category) {
        List<Module> list = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                list.add(m);
            }
        }
        return list;
    }

    public Module getModuleByName(String name) {
        if (name == null) return null;
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }
}
