package com.aghabanafshi.purpleclient.module;

public enum Category {
    COMBAT("Combat", "مبارزه"),
    MOVEMENT("Movement", "حرکت"),
    RENDER("Render", "رندر"),
    PLAYER("Player", "بازیکن"),
    WORLD("World", "جهان"),
    HUD("HUD", "هاد"),
    MISC("Misc", "متفرقه"),
    SETTINGS("Settings", "تنظیمات");

    private final String englishName;
    private final String persianName;

    Category(String englishName, String persianName) {
        this.englishName = englishName;
        this.persianName = persianName;
    }

    public String getEnglishName() { return englishName; }
    public String getPersianName() { return persianName; }
}
