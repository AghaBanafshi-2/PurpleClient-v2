package com.aghabanafshi.purpleclient.module.impl.combat;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ReachDisplay extends Module {
    private double lastReach = 0.0;
    private long reachTime = 0;

    public ReachDisplay() {
        super("Reach Display", "Accurately calculates and displays attack reach distance", Category.COMBAT, 0);
        setEnabled(true);
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (event.target != null && mc.thePlayer != null) {
            Vec3 eyes = mc.thePlayer.getPositionEyes(1.0F);
            Vec3 target = event.target.getPositionVector();
            lastReach = eyes.distanceTo(target);
            reachTime = System.currentTimeMillis();
        }
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        if (!isEnabled()) return;
        if (System.currentTimeMillis() - reachTime < 2500 && lastReach > 0) {
            String text = String.format("Reach: §d%.2fm", lastReach);
            mc.fontRendererObj.drawStringWithShadow(text, 10, 260, 0xFFFFFFFF);
        }
    }
}
