package com.aghabanafshi.purpleclient.module.impl.hud;

import com.aghabanafshi.purpleclient.settings.BooleanSetting;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Coordinates extends HudModule {
    public BooleanSetting showBiome = new BooleanSetting("Show Biome", "biome", true);
    public BooleanSetting showDirection = new BooleanSetting("Show Facing Direction", "dir", true);

    public Coordinates() {
        super("Coordinates", "Shows your XYZ coordinates, biome, and facing direction", 10, 210);
        addSetting(showBiome);
        addSetting(showDirection);
        setEnabled(true);
    }

    @Override
    public void render() {
        if (!isEnabled() || mc.thePlayer == null) return;
        String coords = String.format("XYZ: §d%.1f / %.1f / %.1f", mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
        int currentY = y;

        if (background.isEnabled()) {
            int bgHeight = 14 + (showBiome.isEnabled() ? 12 : 0) + (showDirection.isEnabled() ? 12 : 0);
            Gui.drawRect(x, y, x + width, y + bgHeight, 0x88110726);
        }

        mc.fontRendererObj.drawStringWithShadow(coords, x + 4, currentY + 3, 0xFFFFFFFF);
        currentY += 12;

        if (showBiome.isEnabled()) {
            BlockPos pos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.getEntityBoundingBox().minY, mc.thePlayer.posZ);
            String biome = "Biome: §e" + mc.theWorld.getBiomeGenForCoords(pos).biomeName;
            mc.fontRendererObj.drawStringWithShadow(biome, x + 4, currentY + 3, 0xFFE9D5FF);
            currentY += 12;
        }

        if (showDirection.isEnabled()) {
            int yaw = MathHelper.floor_double((double)(mc.thePlayer.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3;
            String[] dirs = {"South", "West", "North", "East"};
            String dirText = "Facing: §b" + dirs[yaw];
            mc.fontRendererObj.drawStringWithShadow(dirText, x + 4, currentY + 3, 0xFFE9D5FF);
            currentY += 12;
        }

        this.width = 135;
        this.height = currentY - y;
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        render();
    }
}
