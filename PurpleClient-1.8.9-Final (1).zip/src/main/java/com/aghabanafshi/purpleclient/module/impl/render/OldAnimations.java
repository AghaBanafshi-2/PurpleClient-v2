package com.aghabanafshi.purpleclient.module.impl.render;

import com.aghabanafshi.purpleclient.module.Category;
import com.aghabanafshi.purpleclient.module.Module;
import com.aghabanafshi.purpleclient.settings.BooleanSetting;

public class OldAnimations extends Module {
    public BooleanSetting blockhit = new BooleanSetting("1.7 Blockhit", "blockhit", true);
    public BooleanSetting rodAnimation = new BooleanSetting("1.7 Rod Animation", "rod", true);
    public BooleanSetting bowAnimation = new BooleanSetting("1.7 Bow Animation", "bow", true);

    public OldAnimations() {
        super("1.7 Animations", "Brings back smooth 1.7 sword blockhit and swing animations", Category.RENDER, 0);
        addSetting(blockhit);
        addSetting(rodAnimation);
        addSetting(bowAnimation);
        setEnabled(true);
    }
}
