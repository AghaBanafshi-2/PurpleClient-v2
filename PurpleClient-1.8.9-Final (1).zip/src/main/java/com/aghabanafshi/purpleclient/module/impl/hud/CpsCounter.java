package com.aghabanafshi.purpleclient.module.impl.hud;

import com.aghabanafshi.purpleclient.settings.BooleanSetting;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.List;

public class CpsCounter extends HudModule {
    private final List<Long> leftClicks = new ArrayList<Long>();
    private final List<Long> rightClicks = new ArrayList<Long>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public BooleanSetting showRight = new BooleanSetting("Show Right Click", "showRight", true);

    public CpsCounter() {
        super("CPS Counter", "Shows clicks per second for left and right mouse buttons", 10, 28);
        addSetting(showRight);
        setEnabled(true);
    }

    @Override
    public void render() {
        if (!isEnabled()) return;
        long time = System.currentTimeMillis();

        boolean leftDown = Mouse.isButtonDown(0);
        boolean rightDown = Mouse.isButtonDown(1);

        if (leftDown && !wasLeftPressed) leftClicks.add(time);
        if (rightDown && !wasRightPressed) rightClicks.add(time);

        wasLeftPressed = leftDown;
        wasRightPressed = rightDown;

        cleanClicks(leftClicks, time);
        cleanClicks(rightClicks, time);

        String text = "CPS: §d" + leftClicks.size() + (showRight.isEnabled() ? " §7| §d" + rightClicks.size() : "");
        this.width = mc.fontRendererObj.getStringWidth(text) + 8;
        this.height = 14;

        if (background.isEnabled()) {
            int alpha = (int)(opacity.getValue() * 180);
            int bgColor = (alpha << 24) | 0x110726;
            Gui.drawRect(x, y, x + width, y + height, bgColor);
        }
        mc.fontRendererObj.drawStringWithShadow(text, x + 4, y + 3, 0xFFFFFFFF);
    }

    private void cleanClicks(List<Long> clicks, long time) {
        while (!clicks.isEmpty() && time - clicks.get(0) > 1000) {
            clicks.remove(0);
        }
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        render();
    }
}
