package com.aghabanafshi.purpleclient.module.impl.hud;

import com.aghabanafshi.purpleclient.settings.ColorSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FpsDisplay extends HudModule {
    public ColorSetting textColor = new ColorSetting("Text Color", "color", 0xFFFFFFFF);

    public FpsDisplay() {
        super("FPS Display", "Shows real-time frames per second with custom smoothing", 10, 10);
        addSetting(textColor);
        setEnabled(true);
    }

    @Override
    public void render() {
        if (!isEnabled()) return;
        String text = "FPS: §d" + Minecraft.getDebugFPS();
        this.width = mc.fontRendererObj.getStringWidth(text) + 8;
        this.height = 14;

        if (background.isEnabled()) {
            int alpha = (int)(opacity.getValue() * 180);
            int bgColor = (alpha << 24) | 0x110726;
            Gui.drawRect(x, y, x + width, y + height, bgColor);
        }
        mc.fontRendererObj.drawStringWithShadow(text, x + 4, y + 3, textColor.getValue());
    }

    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        render();
    }
}
